<?php
         // geting data 
     
        
        //getting data close
        
include "dbcon.php"; // Using database connection file here

$id = false;
if(isset($_GET['id'])){
    $id = $_GET['id'];
}
 // get id through query string

$del = mysqli_query($con,"delete from social_channel where client_id = '$id'"); // delete query

if($del)
{
    mysqli_close($con); // Close connection
    header("location:addChannel.php"); // redirects to all records page
    exit;	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}
?>