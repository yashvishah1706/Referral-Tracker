<?php  
session_start();
/*
*
* sql connection
*/

$server = "localhost";
$user = "referraltracker_db";
$password = "RefeRRal121@Track";
$db = "referraltracker_db";

    $dbname = "referraltracker_db";
    // Create connection
    $conn = new mysqli($server,$user,$password,$db);

    /* Check connection */
    if($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    /*
    *
    * sql connection
    */
     $current_user = $_SESSION['username'];
    $data_query = $conn->query("SELECT * FROM registration WHERE username = '{$current_user}'");
    while($data = $data_query->fetch_assoc()){
      $profile_no = $data['Profile_No'];
      $user = $data['username'];
      $company = $data['company_name'];
    }
     $_SESSION['profile_no'] = $profile_no ;
     ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ReferralTracker | Channels</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">

    <link rel="stylesheet" href="dash_soumya_style.css">

    <!-- End layout styles -->
    <!-- <link rel="shortcut icon" href="assets/images/favicon.ico" /> -->
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
    <!-- jQuery script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- search code -->
    <style>
    #myInput {
    background-image: url('/css/searchicon.png');
    background-position: 10px 10px;
    background-repeat: no-repeat;
    width: 40%;
    /* float:right; */
    font-size: 16px;
    padding: 12px 20px 12px 40px;
    border: 1px solid #ddd;
    margin-bottom: 12px;
  }

  

  /* #myTable th, #myTable td {
    text-align: left;
    padding: 12px;
  }

  #myTable tr {
    border-bottom: 1px solid #ddd;
  }

  #myTable tr.header, #myTable tr:hover {
    background-color: #f1f1f1;
  } */
  </style>
  <!-- <body>

  <h2>Channels</h2>

  <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for channel.." title="Type in a name">

  <table id="myTable">
    <tr class="header">
      <th style="width:60%;">Name</th>
      <th style="width:40%;">Actions</th>
    </tr>
    <tr>
      <td>Direct</td>
      <td>View	Delete</td>
    </tr>
    <tr>
      <td>Facebook</td>
      <td>View Delete</td>
    </tr>
    <tr>
      <td>Instagram</td>
      <td>View	Delete</td>
    </tr>
  
  </table>

  

  </body> -->

  </head>

  <body>
   

    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="dashboard.php">  Referral Tracker</a>
          <a class="navbar-brand brand-logo-mini" href="dashboard.php">
            <h2>RT</h2>
          </a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>

          

          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <div class="nav-link">
                <div class="nav-profile-image">
                  
                </div>
                <div class="nav-profile-text d-flex flex-column">

                  <span class="font-weight-bold mb-2">
                   
                </div>
              </div>
            </li>
            <li class="nav-item active">
              <a class="nav-link " href="dashboard.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link"  href="profile.php" >
                <span class="menu-title">Account</span>
                <i class="mdi mdi-settings menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php">
                <span class="menu-title">Log Out</span>
                <i class="mdi mdi-logout  menu-icon"></i>
              </a>
            </li>


          </ul>
        </nav>

        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                        <span class="page-title-icon bg-gradient-primary text-white mr-2">
                        <i class="mdi mdi-format-list-bulleted"></i>
                        </span>
                        Channels
                    </h3>

                </div>

                <div>
                    <form class="forms-sample form-inline" method="POST" action="channel_php.php">
                        <input type="text" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" placeholder="Channel Name" name="channel_name">
                        <button type="submit" class="btn btn-gradient-primary mb-2 mr-2" name="add">Add Channel</button>
                    </form>
                    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for channel.." title="Type in a name">
                  <div class="mt-3 grid-margin stretch-card">
                </div>
                  
                  
                    <div class="card">
                      <div class="card-body">
                        <table class="table table-hover" id="myTable">
                          <thead>
                            <tr>
                              <th><h4>Channel Name</h4></th>
                              <th></th>
                              <th></th>
                            </tr>
                          </thead>
                          <tbody>
                          <!-- getting data from db -->
                          <?php

                              $query = "SELECT * FROM dashboard WHERE Profile_No = '{$profile_no}'";
                              // echo "<b> <center>Database Output</center> </b> <br> <br>";

                              if ($result = $conn->query($query)) {

                                  while ($row = $result->fetch_assoc()) {
                                      $Profile_No = $row["Profile_No"];
                                      $channel_name = $row["Channel_Name"];
                                      // $Username = $row["Username"];
                                      $date = $row["Date_Of_Entry"];

                                      $elem = 
                                        '<tr>
                                        <td>'. $channel_name .'</td>
                                        <td style="width: 8.12rem;">
                                        <form   action="cust_details.php" method="GET">
                                        <input class="d-none" type="text" name="channel_value" value="'. $channel_name.'">
                                        <button class="btn btn-gradient-info">view</button>
                                        </form>
                                        </td>
                                        <td style="width: 8.12rem;">
                                        <form   action="deleteChannel.php" method="GET">
                                        <input class="d-none" type="text" name="id_value" value="'. $channel_name.'">
                                        <button type="submit" class="btn btn-gradient-danger"><i class="mdi mdi-delete"></i></button>
                                        </form>
                                        </td>
                                      </tr>';
                                      echo $elem;
                                  }
                                }
                          ?>
                               
                            
                          </tbody>
                        </table>
                      </div>
                    </div>
                    
                  </div>

            </div>
        </div>
      </div>
    </div>

    <!-- all scripts -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>
    <script src="dash_soumya.js" charset="utf-8"></script>
    <script>
  function myFunction() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
  }
  </script>
  </body>
</html>

