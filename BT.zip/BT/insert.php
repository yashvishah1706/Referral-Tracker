<?php
	session_start();
	
   $server = "localhost";
$user = "referraltracker_db";
$password = "RefeRRal121@Track";
$db = "referraltracker_db";
       
	$conn = mysqli_connect($server,$user,$password,$db);

		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
	
	//session
	 $current_user = $_SESSION['username'];
    $data_query = $conn->query("SELECT * FROM registration WHERE username = '{$current_user}'");
    while($data = $data_query->fetch_assoc()){
      $profile_no = $data['Profile_No'];
      $user = $data['username'];
      $company = $data['company_name'];
    }
     $_SESSION['profile_no'] = $profile_no ;


	//channel_value from post variable

	$channel_value = $conn->real_escape_string($_REQUEST['channel_value']);
	
		

		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		
		
		// Taking all 5 values from the form data(input)
              
                //$channel_name=$_SESSION[]
		$Client_Name = $conn->real_escape_string($_REQUEST['Client_Name']);
        $client_lname = $conn->real_escape_string($_REQUEST['client_lname']);                      
        $Ref_by = $conn->real_escape_string($_REQUEST['referred_by']);		
		$Trans_amt = $conn->real_escape_string($_REQUEST['transaction_amount']);               
        $Email_ID = $conn->real_escape_string($_REQUEST['email']);
        $ref_mail= $conn->real_escape_string($_REQUEST['ref_mail']);
		$phone_no= $conn->real_escape_string($_REQUEST['phone_no']);
		$channel_name = $channel_value;  //initialize channel name
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO social_channel (Profile_No, Client_Name, client_lname, Channel_Name, Ref_by, Trans_amt,Email_ID,ref_mail,phone_no) VALUES( '{$profile_no}', '{$Client_Name}','{$client_lname}','{$channel_value}','{$Ref_by}','{$Trans_amt}','{$Email_ID}','{$ref_mail}','{$phone_no}')";
		
		if(mysqli_query($conn, $sql)){		
		
	 header("location:cust_details.php?channel_value=". $channel_value .""); // redirects to all records page		
			
		} else{
			
        echo mysqli_error($conn);
    
		}
		// Close connection
		mysqli_close($conn);
		?>



		
		