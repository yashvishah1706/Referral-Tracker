<?php  
session_start();
/*
*
* sql connection
*/

   $server = "localhost";
$user = "referraltracker_db";
$password = "RefeRRal121@Track";
$db = "referraltracker_db";

    $dbname = "referraltracker_db";
    // Create connection
    $conn = new mysqli($server,$user,$password,$db);

    /* Check connection */
    if($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    /*
    *
    * sql connection
    */
    $current_user = $_SESSION['username'];
    $data_query = $conn->query("SELECT * FROM registration WHERE Username = '{$current_user}'");
    while($data = $data_query->fetch_assoc()){
      $profile_no = $data['Profile_No'];
      $user = $data['username'];
      $company = $data['company_name'];
    }
    $_SESSION['profile_no'] = $profile_no;
    // $profile_no = $_SESSION['profile_no'];
 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ReferralTracker | Channels</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">

    <link rel="stylesheet" href="dash_soumya_style.css">

    <!-- End layout styles -->
    <!-- <link rel="shortcut icon" href="assets/images/favicon.ico" /> -->
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
    <!-- jQuery script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  </head>

  <body>
    

    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="dashboard.php">Referral Tracker</a>
          <a class="navbar-brand brand-logo-mini" href="dashboard.php">
            <h2>RT</h2>
          </a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>

         
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <div class="nav-link">
                <div class="nav-profile-image">
                  
                </div>
                <div class="nav-profile-text d-flex flex-column">

                 
                </div>
              </div>
            </li>
            <li class="nav-item active">
              <a class="nav-link " href="dashboard.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link"  href="profile.php" >
                <span class="menu-title">Account</span>
                <i class="mdi mdi-settings menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php">
                <span class="menu-title">Log Out</span>
                <i class="mdi mdi-logout  menu-icon"></i>
              </a>
            </li>


          </ul>
        </nav>
        <?php
        // geting data 
        $channel_value = $conn->real_escape_string($_GET['channel_value']);
        
        //getting data close
        ?>


        <div class="main-panel">
            <div class="content-wrapper">

                <div class="page-header">
                    <h3 class="page-title">
                        <span class="page-title-icon bg-gradient-primary text-white mr-2">
                          <a style="text-decoration: none;" class="text-light" href="addChannel.php">
                        <i class="mdi mdi-keyboard-backspace"></i></a>
                        </span>
                        <a style="text-decoration: none;" href="addChannel.php" class="text-primary ">All Channels </a><span class="iconify" data-icon="uim:angle-right-b"></span> 
                        Customer Details of <?php  echo $channel_value;?>
                        
                    </h3>

                </div>

                <!-- <div class="col-md-4 col-md-offset-2 stretch-card grid-margin">
                  <div class="card bg-gradient-info card-img-holder text-white">
                    <div class="card-body">
                      <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                      <h4  class="font-weight-normal mb-3 text-center">Add Values </h4>
                      <button id="add-channel-btn">
                      <span class="iconify" data-icon="codicon:add" data-inline="false" style="width: 14rem; height: 1.8125rem;"></span>
                      </button>
                    </div>
                  </div>
                </div>  -->

                <div class="stretch-card grid-margin">
                    <button id="add-channel-btn" class="btn  btn-gradient-info">
                      <span class="iconify" data-icon="codicon:add" data-inline="false" style="width: 2rem; height: 1.8125rem; padding-right: 10px;"></span>
                      Add Customers
                    </button>
                </div>
                

                <div class="stretch-card table-responsive" >
                  <div class="card">
                    <div class="card-body ">
                  
                      <table  class="table table-hover  table-responsive">
                        <thead>
                          <tr class="">
                            <th>First Name</th> 
                            <th>Last Name</th>           
                            <th>Phone Number</th>
                            <th>Mail</th>
                            <th>Transaction Amount</th>
                            <th></th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>


                          <?php

                          // new code starts
                          $sql = "SELECT * from social_channel where Profile_No = '{$profile_no}' and Channel_Name='{$channel_value}'";
                          //fetch data from database
                          $records = $conn->query($sql);

                          if (mysqli_num_rows($records) > 0) {
                           
                          while($data = $records->fetch_assoc())
                          {  
                            $Fname = $data["Client_Name"];
                            $Lname = $data["client_lname"];
                            $Pno = $data["phone_no"];
                            $maill = $data["Email_ID"];
                            $amt = $data["Trans_amt"];
                            $elem = '<tr >
                                      <td>'. $data["Client_Name"] .'</td>
                                      <td>'. $Lname .'</td>
                                      <td>'. $Pno .'</td>
                                      <td>'. $maill .'</td>
                                      <td>'. $amt .'</td>
                                      <td><a class="btn btn-gradient-success" href="edit.php?id='. $data['client_id'] . '&channel_value='. $channel_value .'" role="button">Edit</a>
                                      </td>
                                      <td><a class="btn btn-gradient-danger" href="delete.php?id='. $data['client_id'] . '" role="button">Delete</a></td>
                                    </tr>';

                            echo 	$elem;

                          }
                        }
                          else {
                            echo "not worked";
                          }
                          ?> 
                                           
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                <!-- adding modal window form -->
                <div class="channelOption d-none" >
                  <div class="channelOptionContent " >
                    <div class="card-body " >
        
                      <form action="insert.php" method="POST" class="forms-sample ">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-4 col-form-label">First Name</label>
                              <div class="col-sm-8">
                                <input type="text"class="form-control" name="Client_Name"  placeholder=" First Name" Required>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label  class="col-sm-4 col-form-label">Last Name</label>
                              <div class="col-sm-8">
                                <input type="text"class="form-control" name="client_lname"  placeholder="Last Name" Required>
                              </div>
                            </div>
                          </div>
                        </div> 
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label  class="col-sm-4 col-form-label">Phone Number</label>
                              <div class="col-sm-8">
                                <input type="text" class="form-control" name="phone_no"  placeholder="Phone Number" Required>
                              </div>
                            </div> 
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label  class="col-sm-4 col-form-label">Email</label>
                              <div class="col-sm-8">
                                <input type="text" class="form-control" name="email"  placeholder="Email" Required>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                          <div class="form-group row">
                            <label  class="col-sm-4 col-form-label">Referred By</label>
                            <div class="col-sm-8">
                              <input type="text" class="form-control" name="referred_by"  placeholder="Referred By" > 
                            </div>
                          </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label  class="col-sm-4 col-form-label"> Ref by Email</label>
                              <div class="col-sm-8">
                                <input type="text" class="form-control" name="ref_mail"  placeholder="Ref Email" >
                              </div>
                            </div> 
                          </div>
                        </div>
                          
                        <div class="form-group row">
                          <label  class="col-sm-2 col-form-label">Transaction Amount</label>
                          <div class="col-sm-10">
                          <input type="text" class="form-control" name="transaction_amount"  placeholder="Transaction Amount" Required>  
                          </div>
                        </div>

                        <input class="d-none" type="text" name="channel_value" value="<?php echo $channel_value; ?>">
                        
                      
                      <input type="submit" class="btn btn-gradient-info" value="Submit">
                        <div id="addChannelCancel" class="btn btn-light">Cancel</div>
                      </form>

                    </div>
                  </div>
                </div>
                <!-- modal form end -->

            </div>
          </div>
        </div>
      </div>

    <!-- all scripts -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>
    <script src="dash_soumya.js" charset="utf-8"></script>
  </body>
</html>