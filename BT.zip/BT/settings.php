<?php
session_start();
/*
*
* sql connection
*/

include "dbcon.php"; 
// $servername = "localhost";
// $username = "root";
// // $password = "RefeRRal121@Track";
// $password = "";


// $dbname = "referraltracker_db";
// // Create connection
// $conn = new mysqli($servername, $username, $password, $dbname);

// /* Check connection */
// if($conn->connect_error) {
//   die("Connection failed: " . $conn->connect_error);
// }
/*
*
* sql connection
*/
$current_user = $_SESSION['username'];
$data_query = $con->query("SELECT * FROM registration WHERE username = '{$current_user}'");
while($data = $data_query->fetch_assoc()){
  $profile_no = $data['Profile_No'];
  $user = $data['username'];
  $company = $data['company_name'];
  $mob = $data['mobile'];
  $email = $data['email'];
  $comp_ad = $data['company_address'];

}
 $_SESSION['profile_no'] = $profile_no ;

?>
<?php 

include "dbcon.php";
$current_user = $_SESSION['username'];
    $data_query = $con->query("SELECT * FROM registration WHERE username = '{$current_user}'");
    while($data = $data_query->fetch_assoc()){
      $profile_no = $data['Profile_No'];
      $user = $data['username'];
      $company = $data['company_name'];
      $mobile=$data['mobile'];
    }
     $_SESSION['id'] = $profile_no ;

 $email_search = " select * from registration where  Profile_No= '$profile_no'";
        $query = mysqli_query($con, $email_search);

        $email_count = mysqli_num_rows($query);

$data = mysqli_fetch_array($query);

 ?>
<!DOCTYPE html>
<html lang="en">

  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ReferralTracker | Settings</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
   <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.ico" />
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="dashboard.php">Referral Tracker</a>
          <a class="navbar-brand brand-logo-mini" href="dashboard.php">
          <h2>RT</h2>
          </a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>

          
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
             
              <div class="nav-profile-text d-flex flex-column">

                <span class="font-weight-bold mb-2">
                    <a style="padding: 12px;" class="nav-link" href="profile.php"><?php echo $user; ?></a>
                </span>
                <span class="text-dark text-medium"> <?php
            $maximumPoints=100;
                    

                    if($data['email'] != '')
                      $completedEmail = 20;
                    else $completedEmail = 0;

                    if($data['mobile'] != '')
                       $completedmobile = 20;
                     else $completedmobile = 0;

                    if($data['company_name'] != '')
                        $completedName= 30;
                      else $completedName = 0;

                    if($data['company_address'] != '')
                        $completedAddress =30;
                      else $completedAddress = 0;

$percent = ($completedEmail+$completedmobile+$completedName+$completedAddress)*$maximumPoints/100;

echo "".$percent."% is completed";

?></span>
              </div>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
              <span class="menu-title">Dashboard</span>
              <i class="mdi mdi-home menu-icon"></i>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link active"  href="profile.php" >
              <span class="menu-title">Accounts</span>
              <i class="mdi mdi-settings menu-icon"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login.php">
              <span class="menu-title">Log Out</span>
              <i class="mdi mdi-logout  menu-icon"></i>
            </a>
          </li>


        </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">

<div class="container">
  <div class="row justify-content-center">
    <div class="col-12 col-lg-10 col-xl-8 mx-auto">
        <!-- <h2 class="h3 mb-4 page-title">Settings</h2> -->
        <div class="my-4 nav-tab" >
          <nav class="navbar-expand-lg navbar-light ">
              <ul class="navbar-nav navbar-nav-right">
                  <li class="nav-item ">
                    <a class="nav-link h5" href="settings.php">Settings</a>
                  </li>
                  <li class="nav-item ">
                    <a class="nav-link active text-primary h5" href="profile.php">Profile</a>
                  </li>

              </ul>
            </nav>
          </nav>


            <form method="post" action="set2.php">
                <div class="row mt-5 align-items-center">
                   
                    
                    <div class="col">
                        <div class="row align-items-center">
                            <div class="col-md-7">
                                <h1 class="mb-1"><?php echo $user; ?></h1>
                                <h3 class="small mb-3"><span class="text-muted"><?php echo $data['company_address']; ?></span></h3>
                            </div>
                        </div>
                        <!--div class="row mb-4">
                            <div class="col-md-7">
                                <p class="text-dark">
                                    ---Little info about Company--- <br>
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                </p>
                            </div>
                            <div class="col">
                                <p class="small mb-0 text-dark">Contact:</p>
                                <p class="small mb-0 text-muted">------Email-----</p>
                                <p class="small mb-0 text-muted">------Phone/Mob.------</p>
                            </div-->
                        </div>
                    </div>
                </div>
                <hr class="my-4" />
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="firstname">Username</label>
                        <input type="text" name="name" class="form-control"   value="<?php echo $user; ?>" disabled/>
						
                    </div>
                    <div class="form-group col-md-6">
                        <label for="lastname">Phone Number</label>
                        <input type="text" name="phno" class="form-control" value="<?php echo $mob; ?>" required/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputEmail4">Email</label>
                    <input type="email" class="form-control" name='email' value="<?php echo $email; ?>" disabled/>
                </div> 
                <div class="form-group">
                    <label for="inputAddress5">Address</label>
                    <input type="text" class="form-control" name="company_address" value=" <?php echo $comp_ad; ?>" required />
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputCompany5">Company</label>
                        <input type="text" class="form-control" name="company_name" value= " <?php echo $company; ?>"required/>
                    </div>
                    <!--div class="form-group col-md-4">
                        <label for="inputState5">State</label>
						<input type="text"  class ="form-control" id="inputState6" value="Telangana"/>
                        < !--select id="inputState5" class="form-control">
                            <option selected="">Choose...</option>
                            <option>...</option>
                        </select>
                    </div>
                    <div class="form-group col-md-2">
                        <label for="inputZip5">Zip</label>
                        <input type="text" class="form-control" id="inputZip5" value="98232" />
                    </div-->
                </div>
                <hr class="my-4" />
                <!-- <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="inputPassword4">Old Password</label>
                            <input type="password" class="form-control" name="password" />
                        </div>
                        <div class="form-group">
                            <label for="inputPassword5">New Password</label>
                            <input type="password" class="form-control" name="newpassword" />
                        </div>
                        <div class="form-group">
                            <label for="inputPassword6">Confirm Password</label>
                            <input type="password" class="form-control" name="confirmnewpassword" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p class="mb-2">Password requirements</p>
                        <p class="small text-muted mb-2">To create a new password, you have to meet all of the following requirements:</p>
                        <ul class="small text-muted pl-4 mb-0">
                            <li>Minimum 8 character</li>
                            <li>At least one special character</li>
                            <li>At least one number</li>
                            <li>Can’t be the same as a previous password</li>
                        </ul>
                    </div>
                </div> -->
                <button type="submit" class="btn btn-gradient-primary">Save Change</button>
				 <!--h2> <?php echo "$value"; ?> </h2-->
				
            </form>
        </div>
    </div>
  </div>

</div>

<div> <!--content-wrapper-vendors-->

  <!-- footer -->
  <footer class="footer">
    <div class="container-fluid clearfix" style="color: #444444;">
      <span class="d-block text-center text-left d-sm-inline-block">Copyright © <a style="text-decoration: none; color: #444444;" href="http://www.abcinfomedia.com">ABC Infomedia Pvt Ltd</a> • 2021</span>
      <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">All Rights Reserved • <a style="color: #444444;" href="http://www.referraltracker.in" >ReferralTracker </a></span>
    </div>
  </footer>

</div>  <!-- main-panel ends -->

</div>
<!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
<!-- plugins:js -->
<script src="assets/vendors/js/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<script src="assets/vendors/chart.js/Chart.min.js"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="assets/js/off-canvas.js"></script>
<script src="assets/js/hoverable-collapse.js"></script>
<script src="assets/js/misc.js"></script>
<!-- endinject -->
<!-- Custom js for this page -->
<script src="assets/js/dashboard.js"></script>
