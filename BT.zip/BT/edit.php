<?php
session_start();
include "dbcon.php"; // Using database connection file here

$id = false;
if(isset($_GET['id'])){
    $id = $_GET['id'];
}
$channel_value = $_GET['channel_value'];

$qry = mysqli_query($con,"select * from social_channel where client_id='$id'"); // select query

$data = mysqli_fetch_array($qry); // fetch data

if(isset($_POST['update'])) // when click on Update button
{
   $Client_Name = $_POST['Client_Name'];
   $client_lname = $_POST['client_lname'];                      
   $Ref_by = $_POST['Ref_by'];		
	 $Trans_amt = $_POST['Trans_amt'];               
   $Email_ID = $_POST['Email_ID'];
   $ref_mail=$_POST['ref_mail'];
	 $phone_no=$_POST['phone_no'];
	
   $edit = mysqli_query($con,"update social_channel set Email_ID='$Email_ID',phone_no='$phone_no',Client_Name='$Client_Name',client_lname='$client_lname',Ref_by='$Ref_by',ref_mail='$ref_mail',Trans_amt='$Trans_amt'where client_id='$id'");
//$edit = "INSERT INTO channel_table(first_name,last_name,email_id,referred_by,source,transaction_amount,date) VALUES ('$first_name','$last_name','$email','$referred_by','$source','$transaction_amount','$date')";	
    if($edit)
    {
        mysqli_close($con); // Close connection
        header("location:cust_details.php?channel_value=". $channel_value .""); // redirects to all records page
        exit;
    }
    else
    {
        echo mysqli_error($con);
    }    	
}
?>
<!DOCTYPE html>
<html>
<head>
 
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ReferralTracker</title>
    
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.ico" />
   
  </head>

<body>
     <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
     <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
            <a class="navbar-brand brand-logo" href="dashboard.php">Referral Tracker</a>
            <a class="navbar-brand brand-logo-mini" href="dashboard.php">
            <img src="" alt="logo" />
          </a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>

          <ul class="navbar-nav navbar-nav-right">
           
            <li class="nav-item d-none d-lg-block full-screen-link">
              <a class="nav-link">
                <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
              </a>
            </li>

          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
       <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
       
        

 <div class="main-panel">
          <div class="content-wrapper">
               <div class="page-header">
<h2>Update Data</h2>
              </div>
<div class="row ">
<div class="stretch-card ">
<div class="card">
    <div class="card-body ">
<form  method="POST" class="forms-sample ">
    <div class="form-group row">
    <label class="col-sm-4 col-form-label">First Name</label>
    <div class="col-sm-8">
      <input type="text"class="form-control" name="Client_Name" value="<?php echo $data['Client_Name'] ?>" placeholder="First Name" Required>
    </div>
      </div>
   <div class="form-group row">
    <label  class="col-sm-4 col-form-label">Last Name</label>
    <div class="col-sm-8">
     <input type="text"class="form-control" name="client_lname" value="<?php echo $data['client_lname'] ?>" placeholder="Last Name" Required>
    </div>
    </div>
     <div class="form-group row">
    <label  class="col-sm-4 col-form-label">Phone Number</label>
    <div class="col-sm-8">
     <input type="text"class="form-control" name="phone_no" value="<?php echo $data['phone_no'] ?>" placeholder="Phone Number" Required>
    </div>
    </div>
   <div class="form-group row">
  <label  class="col-sm-4 col-form-label">Email</label>
  <div class="col-sm-8">
    <input type="text" class="form-control" name="Email_ID" value="<?php echo $data['Email_ID'] ?>" placeholder="Email" Required>
  </div>
</div> 
  
<div class="form-group row">
  <label  class="col-sm-4 col-form-label">Referred By</label>
  <div class="col-sm-8">
  <input type="text" class="form-control" name="Ref_by"  value="<?php echo $data['Ref_by'] ?>" placeholder="Referred By" > 
  </div>
</div>
    <div class="form-group row">
  <label  class="col-sm-4 col-form-label">Referred By Email Id</label>
  <div class="col-sm-8">
  <input type="text" class="form-control" name="ref_mail"  value="<?php echo $data['ref_mail'] ?>" placeholder="Referred By mail" > 
  </div>
</div>
<div class="form-group row">
  <label  class="col-sm-4 col-form-label">Transaction Amount</label>
  <div class="col-sm-8">
   <input type="text" class="form-control" name="Trans_amt"  value="<?php echo $data['Trans_amt'] ?>" placeholder="Transaction Amount" Required>  
  </div>
</div>

 <input type="submit" class="btn btn-gradient-primary" name="update" value="Update">
</form>
            </div>
          </div>
      </div>
     </div>

              
          </div>
     
          </div>
         
 </div>
     <footer class="footer">
            <div class="container-fluid clearfix" style="color: #444444;">
              <span class="d-block text-center text-left d-sm-inline-block">Copyright © <a style="text-decoration: none; color: #444444;" href="http://www.abcinfomedia.com">ABC Infomedia Pvt Ltd</a> • 2021</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">All Rights Reserved • <a style="color: #444444;" href="http://www.referraltracker.in" >ReferralTracker </a></span>
            </div>
          </footer>  
     </div>
    
 <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../../assets/js/off-canvas.js"></script>
    <script src="../../assets/js/hoverable-collapse.js"></script>
    <script src="../../assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
         
 
</body>
</html>j
