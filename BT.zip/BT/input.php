<html>
<head>
<title>
Manasa</title>
<?php 
session_start();
include "dbcon.php";
$current_user = $_SESSION['username'];
    $data_query = $con->query("SELECT * FROM registration WHERE username = '{$current_user}'");
    while($data = $data_query->fetch_assoc()){
      $profile_no = $data['id'];
      $user = $data['username'];
      $company = $data['company_name'];
      $mobile=$data['mobile'];
    }
     $_SESSION['id'] = $profile_no ;

 $email_search = " select * from registration where id= '$profile_no'";
        $query = mysqli_query($con, $email_search);

        $email_count = mysqli_num_rows($query);

while($data = mysqli_fetch_array($query))
{
 ?>
<form method='post' >
<label >Email</label>
<input type ="text" name='nm' value="<?php echo $data['email'] ?>" />
<label> Name</label>
<input type="text"  name='na' value="<?php echo $data['username'] ?>"/>
<label>Phone Number</label>
<input type="int"  name='pn' value="<?php echo $data['mobile'] ?>"/>

</form>

<?php
}
?>

</head>
</html>
