$("#add-channel-btn").click( function () {
  $(".channelOption").removeClass("d-none");
} );

$("#addChannelOk").click( function () {
  $(".channelOption").addClass("d-none");
});
$("#addChannelCancel").click( function () {
  $(".channelOption").addClass("d-none");
});

$("#mannualEntry").hover( function(){
  $(this).addClass("cur-pointer"); 
});
