<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ReferralTracker | Details</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->

    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="dashboard.php">Referral Tracker</a>
          <a class="navbar-brand brand-logo-mini" href="index.html">
            <h2>RT</h2>
          </a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>

          
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <div class="nav-link">
                
                <div class="nav-profile-text d-flex flex-column">
                  
                </div>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="dashboard.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link"  href="profile.php" >
                <span class="menu-title">Account</span>
                <i class="mdi mdi-settings menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php">
                <span class="menu-title">Log Out</span>
                <i class="mdi mdi-logout  menu-icon"></i>
              </a>
            </li>


          </ul>
        </nav>
        <!-- partial -->
       


        <div class="main-panel">
          <div class="content-wrapper">

            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" > Customers Details</h4>
                    <hr width="10%" color="blue" size="5px" style="border:2px solid blue ;border-radius: 10px;" align="left">
                    <?php
                      $details = $_GET["id_value"];
                      $server = "localhost";
                      $user = "referraltracker_db";
                      $password = "RefeRRal121@Track";
                      $db = "referraltracker_db";

                      $conn = mysqli_connect($server,$user,$password,$db);

                         if ($conn-> connect_error) {
                           die("Connection Failed:".$conn-> connect_error);
                         }
                      $sql = "SELECT Client_Name,Email_ID,phone_no,d_date,Channel_Name,Ref_by,ref_mail,Trans_amt from social_channel Where phone_no='{$details}'";
                        $result = $conn-> query($sql);

                      if ($result-> num_rows > 0) {
                           while ($row = $result-> fetch_assoc()) {
                             echo "<div class='row'><div class='col-lg-2'><h3>NAME:</h3></div><div class='col-lg-10'>".$row["Client_Name"]."</div></div><div class='row'><div class='col-lg-2'><h3>Channel:</h3></div><div class='col-lg-10'>".$row["Channel_Name"]."</div></div><div class='row'><div class='col-lg-2'><h3>E-MAIL:</h3></div><div class='col-lg-10'>".$row["Email_ID"]."</div></div><div class='row'><div class='col-lg-2'><h3>REFERRED BY:</h3></div><div class='col-lg-10'>".$row["Ref_by"]."</div></div><div class='row'><div class='col-lg-2'><h3>PHONE NO:</h3></div><div class='col-lg-10'>".$row["phone_no"]."</div></div><div class='row'><div class='col-lg-2'><h3>DATE & TIME:</h3></div><div class='col-lg-10'>".$row["d_date"]."</div></div><div class='row'><div class='col-lg-2'><h3>AMOUNT:</h3></div><div class='col-lg-10'>".$row["Trans_amt"]."</div></div>";
                              }
                           echo "</table>";
                         }
                        

                         
                         
                        

?>

                    
      <br><br>             
                 

<?php








                echo "<h3>Referred To:</h3>
                  <hr width='30%' color='blue' size='5px' style='border:2px solid blue ;border-radius: 10px;' align='left'>";
             
                                   
                    
                    $sum = 0;

                     $sql = "SELECT Client_Name,Email_ID,phone_no,d_date,Channel_Name,Ref_by,ref_mail,Trans_amt from social_channel Where phone_no='{$details}'";
                        $result = $conn-> query($sql);
                        while ($row = $result-> fetch_assoc()) {
                             //dddd
                          //echo $row["Client_Name"].$row["ref_mail"].$row["Ref_by"]."<br>";
                          $refby = $row["Client_Name"];
                          $refmail = $row["Email_ID"];
                          
                              };

                        $sql1 = "SELECT Client_Name,Trans_amt,phone_no from social_channel Where Ref_by='{$refby}' and ref_mail='{$refmail}'";
                        $result = $conn-> query($sql1);

                        if ($result-> num_rows > 0) {
                        echo "<table class='table table-striped'>

                        <tr>
                          <th> Name </th>
                          <th>Amount</th>
                          <th>Details</th>  
                          
                        </tr>";

                           while ($row = $result-> fetch_assoc()) {
                             echo "<tr><td>".$row["Client_Name"]."</td><td>".$row["Trans_amt"]."</td><td>".'<form   action="details.php" method="GET">
                                      <input class="d-none" type="text" name="id_value" value= '. $row["phone_no"].'><br>
                                      <input type="submit" value="View">
                                    </form>'."</td>";
                              $sum = $sum+$row["Trans_amt"];}
                              echo "<h2>Total:</h2>".$sum;
                              echo "</table>";
                           echo "</table>";
                         }
                         else echo"<h2>NO referrals</h2";

                        
                     
?>
                  </div></div></div>


            

                </div>
              </div>
            </div>

          </div>


          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid clearfix" style="color: #444444;">
              <span class="d-block text-center text-left d-sm-inline-block">Copyright © <a style="text-decoration: none; color: #444444;" href="http://www.abcinfomedia.com">ABC Infomedia Pvt Ltd</a> • 2021</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">All Rights Reserved • <a style="color: #444444;" href="http://www.referraltracker.in" >ReferralTracker </a></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>
