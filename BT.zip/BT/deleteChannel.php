<?php
session_start();
/*
*
* sql connection
*/

$server = "localhost";
$user = "referraltracker_db";
$password = "RefeRRal121@Track";
$db = "referraltracker_db";

    $dbname = "referraltracker_db";
    // Create connection
    $conn = new mysqli($server,$user,$password,$db);

    /* Check connection */
    if($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    /*
    *
    * sql connection
    */

 $current_user = $_SESSION['username'];
    $data_query = $conn->query("SELECT * FROM registration WHERE username = '{$current_user}'");
    while($data = $data_query->fetch_assoc()){
      $profile_no = $data['Profile_No'];
      $user = $data['username'];
      $company = $data['company_name'];
    }
     $_SESSION['profile_no'] = $profile_no ;

$id = $_GET['id_value'];
// if (isset($_GET['submit'])) {
 
$sql = "DELETE FROM dashboard WHERE Profile_No = '{$profile_no}' and Channel_Name = '{$id}'";
$sql2 = "DELETE FROM social_channel WHERE Profile_No = '{$profile_no}' and Channel_Name = '{$id}'";
$conn->query($sql2);
if($conn->query($sql)){
  // echo "deleted!";
}
else{
  // echo "not deleted!";
}
header("Location:addChannel.php");
exit();
$conn->close();
?>