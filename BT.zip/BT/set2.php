 <?php
session_start();
/*
*
* sql connection
*/

$server = "localhost";
$user = "referraltracker_db";
$password = "RefeRRal121@Track";
$db = "referraltracker_db";

$dbname = "referraltracker_db";
    // Create connection
    $conn = new mysqli($server,$user,$password,$db);

    /* Check connection */
    if($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    /*
    *
    * sql connection
    */
$current_user = $_SESSION['username'];
    $data_query = $conn->query("SELECT * FROM registration WHERE username = '{$current_user}'");
    while($data = $data_query->fetch_assoc()){
      $profile_no = $data['Profile_No'];            //data from db
      $user = $data['username'];                    //data from db
      $company = $data['company_name'];             //data from db
      $mob=$data['mobile'];                         //data from db
    }
     $_SESSION['profile_no'] = $profile_no ;

$company_name=$conn->real_escape_string($_POST['company_name']);               //data from update details form 
$company_address=$conn->real_escape_string($_POST['company_address']);         //data from update details form
$mobile=$conn->real_escape_string($_POST['phno']);                             //data from update details form
$name=$conn->real_escape_string($_POST['name']);                              //data from update details form


echo $profile_no;

if($company_name !='')
{
$update_name=mysqli_query($conn,"update registration set company_name='{$company_name}' where Profile_No = '{$profile_no}'");	
}
if($company_address !='')
{
$update_company_address=mysqli_query($conn,"update registration set company_address ='{$company_address}' where Profile_No= '{$profile_no}'");	
}
if($mobile!='')
{
$update_Phoneno=mysqli_query($conn,"update registration set mobile='{$mobile}' where Profile_No = '{$profile_no}'");
}
header("Location:profile.php");
?>