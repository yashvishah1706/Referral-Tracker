<?php
$server = "localhost";
$user = "referraltracker_db";
$password = "RefeRRal121@Track";
$db = "referraltracker_db";

$con = mysqli_connect($server,$user,$password,$db);

if(!$con)
{
    die("Connection failed: " . mysqli_connect_error());
}

 ?>
