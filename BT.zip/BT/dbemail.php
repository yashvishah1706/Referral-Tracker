<?php 
$server = "localhost";
$user = "referraltracker_db";
$password = "RefeRRal121@Track";
$db = "referraltracker_db";
$con = mysqli_connect($server,$user,$password,$db);


if($con){
?>
<script>alert("connection successfull");</script>
<?php

}else {
	
	?>
<script>alert("  no connection");</script>
<?php
}

 ?>