<?php 
session_start();
include "dbcon.php";
$current_user = $_SESSION['username'];
    $data_query = $con->query("SELECT * FROM registration WHERE username = '{$current_user}'");
    while($data = $data_query->fetch_assoc()){
      $profile_no = $data['Profile_No'];
      $user = $data['username'];
      $company = $data['company_name'];
      $mobile=$data['mobile'];
    }
     $_SESSION['id'] = $profile_no ;

 $email_search = " select * from registration where  Profile_No= '$profile_no'";
        $query = mysqli_query($con, $email_search);

        $email_count = mysqli_num_rows($query);

$data = mysqli_fetch_array($query);

 ?>

<!DOCTYPE html>
<html lang="en">
<html>


<head>
    <meta charset="utf-8">
    <!--  This file has been downloaded from bootdey.com @bootdey on twitter -->
    <!--  All snippets are MIT license http://bootdey.com/license -->
    <title>ReferralTracker | Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="dash_soumya_style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.ico" />
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
    <!-- jQuery script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo" href="dashboard.php">Referral Tracker</a>
        <a class="navbar-brand brand-logo-mini" href="dashboard.php">
          <h2>RT</h2>
        </a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-stretch">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="mdi mdi-menu"></span>
        </button>

        <ul class="navbar-nav navbar-nav-right">
         
          <li class="nav-item d-none d-lg-block full-screen-link">
            <a class="nav-link">
              <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
            </a>
          </li>

        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
             
              <div class="nav-profile-text d-flex flex-column">

                <span class="font-weight-bold mb-2">
                    <a style="padding: 12px;" class="nav-link" href="profile.php"><?php echo $user; ?></a>
                </span>
                <span class="text-dark text-medium"> <?php
				    $maximumPoints=100;
                    

                   if($data['email'] != '')
                      $completedEmail = 20;
                    else $completedEmail = 0;

                    if($data['mobile'] != '')
                       $completedmobile = 20;
                     else $completedmobile = 0;

                    if($data['company_name'] != '')
                        $completedName= 30;
                      else $completedName = 0;

                    if($data['company_address'] != '')
                        $completedAddress =30;
                      else $completedAddress = 0;

$percent = ($completedEmail+$completedmobile+$completedName+$completedAddress)*$maximumPoints/100;

echo "".$percent."% is completed";

?></span>
              </div>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
              <span class="menu-title">Dashboard</span>
              <i class="mdi mdi-home menu-icon"></i>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link active"  href="settings.php" >
              <span class="menu-title">Accounts</span>
              <i class="mdi mdi-settings menu-icon"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login.php">
              <span class="menu-title">Log Out</span>
              <i class="mdi mdi-logout  menu-icon"></i>
            </a>
          </li>


        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">

          <div class="container">

            <div class="row justify-content-center">
              <div class="col-lg-12 col-xl-10 mx-auto">



            <nav class="navbar-expand-lg navbar-light ">
              <ul class="navbar-nav navbar-nav-right">
                  <li class="nav-item ">
                    <a class="nav-link h5" href="settings.php">Settings</a>
                  </li>
                  <li class="nav-item ">
                    <a class="nav-link active text-primary h5" href="profile.php">Profile</a>
                  </li>

              </ul>
            </nav>
            <div class="row gutters-sm">
              

              <!--  -->
              <div class="col-md-8">
                <div class="card mb-3">
                  <div class="card-body">
                       <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Company Name</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <?php echo $data['company_name'] ?>
                      </div>
                       </div><hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Username</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                       <p class="mb-1 text-black"> <?php echo $data['username'] ?></p>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Email</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                       <p class="mb-1 text-black"> <?php echo $data['email'] ?></p>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Phone</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <p class="mb-1 text-black"> <?php echo $data['mobile'] ?></p>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Company Name</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                                           <p class="mb-1 text-black"><?php echo $data['company_name']?></p>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Address</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                       <p class="mb-1 text-black"> <?php echo $data['company_address'] ?></p>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-12">
                        <a class="btn btn-gradient-primary"  href="settings.php">Edit</a>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
          </div>


        </div> <!-- col-lg-10 close -->
          </div> <!-- row close -->
        </div>  <!-- container close -->


        <!-- footer -->
        <footer class="footer">
          <div class="container-fluid clearfix" style="color: #444444;">
            <span class="d-block text-center text-left d-sm-inline-block">Copyright © <a style="text-decoration: none; color: #444444;" href="http://www.abcinfomedia.com">ABC Infomedia Pvt Ltd</a> • 2021</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">All Rights Reserved • <a style="color: #444444;" href="http://www.referraltracker.in" >ReferralTracker </a></span>
          </div>
        </footer>

      </div> <!--content-wrapper-vendors-->

    </div>  <!-- main-panel ends -->

</div>
<!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
<!-- plugins:js -->
<script src="assets/vendors/js/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<script src="assets/vendors/chart.js/Chart.min.js"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="assets/js/off-canvas.js"></script>
<script src="assets/js/hoverable-collapse.js"></script>
<script src="assets/js/misc.js"></script>
<!-- endinject -->
<!-- Custom js for this page -->
<script src="assets/js/dashboard.js"></script>
</body>

</html>

