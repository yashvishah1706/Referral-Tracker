<?php
session_start();
$server = "localhost";
$user = "referraltracker_db";
$password = "RefeRRal121@Track";
$db = "referraltracker_db";

$conn = mysqli_connect($server,$user,$password,$db);

                         if ($conn-> connect_error) {
                           die("Connection Failed:".$conn-> connect_error);
                         }
$current_user = $_SESSION['username'];
    $data_query = $conn->query("SELECT * FROM registration WHERE username = '{$current_user}'");
    while($data = $data_query->fetch_assoc()){
      $profile_no = $data['Profile_No'];
      $user = $data['username'];
      $company = $data['company_name'];
    }
     $_SESSION['profile_no'] = $profile_no ;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ReferralTracker | Customers</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
  </head>
  <body>
    <div class="container-scroller">
        
      <!-- partial:partials/_navbar.html -->
               <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="dashboard.php">  Referral Tracker</a>
          <a class="navbar-brand brand-logo-mini" href="dashboard.php">
            <h2>RT</h2>
          </a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>

          <ul class="navbar-nav navbar-nav-right">
           
            <li class="nav-item d-none d-lg-block full-screen-link">
              <a class="nav-link">
                <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
              </a>
            </li>

          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <div class="nav-link">
               
   
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="dashboard.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link"  href="profile.php" >
                <span class="menu-title">Account</span>
                <i class="mdi mdi-settings menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php">
                <span class="menu-title">Log Out</span>
                <i class="mdi mdi-logout  menu-icon"></i>
              </a>
            </li>


          </ul>
        </nav>
        <!-- partial -->
       <style type="text/css">
         #myInput1, #myInput2, #myInput3 {
          background-image: url('/css/searchicon.png');
          background-position: 10px 10px;
          background-repeat: no-repeat;
          width: 25%;
          font-size: 16px;
          padding: 12px 20px 12px 40px;
          border: 1px solid #ddd;
          margin-bottom: 12px;
          margin-left:50px;
            }
       </style>


        <div class="main-panel">
          <div class="content-wrapper">

            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h2 class="card-title"> Customers </h2>
                    <hr width="5%" color="blue" size="5px" style="border:2px solid blue ;border-radius: 10px;" align="left">
                    


                    <br><h4>Search By:</h4>
                    <input type="text" id="myInput1" onkeyup="myFunction1()" placeholder="Name.." title="Type in a name">
                    <input type="text" id="myInput2" onkeyup="myFunction2()" placeholder="Phone no.." title="Phone No.">
                    <input type="text" id="myInput3" onkeyup="myFunction3()" placeholder="Email.." title="Type in an email">
                    


                    <table id="myTable" class="table table-striped">

                        <tr>

                          <th> Name </th>
                          <th>E-mail</th>
                          <th> Phone No. </th>
                          
                          <th> Details </th>
                          
                        </tr>
                        <?php
                        
                      




                         $sql = "SELECT Client_Name,Email_ID,phone_no from social_channel where Profile_No='$profile_no' /*AND Channel_Name = 'twitter'*/";
                         $result = $conn-> query($sql);

                         if ($result-> num_rows > 0) {
                           while ($row = $result-> fetch_assoc()) {
                             echo "<tr><td>".$row["Client_Name"]."</td><td>".$row["Email_ID"]."</td><td>".$row["phone_no"]."</td><td>".
                                '<form   action="details.php" method="GET">
                                      <input class="d-none" type="text" name="id_value" value= '. $row["phone_no"].'><br>
                                      <input class = "d-none" type="submit" value="View">
                                      <button class="btn btn-gradient-info">view</button>
                                    </form>'."</td>";
                           }
                           echo "</table>";
                         }
                         $conn-> close();


                        ?>

                        <br><br>
                        



                    </table>
                  </div></div></div>


            

                </div>
              </div>
            </div>

          </div>

          <script>
function myFunction1() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput1");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}

function myFunction2() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput2");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}

function myFunction3() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput3");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>


          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid clearfix" style="color: #444444;">
              <span class="d-block text-center text-left d-sm-inline-block">Copyright © <a style="text-decoration: none; color: #444444;" href="http://www.abcinfomedia.com">ABC Infomedia Pvt Ltd</a> • 2021</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">All Rights Reserved • <a style="color: #444444;" href="http://www.referraltracker.in" >ReferralTracker </a></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>
