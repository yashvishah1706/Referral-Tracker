
<!DOCTYPE html>
<html>
<head>
  
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="dash_soumya_style.css">
    <!-- End layout styles -->
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
    <!-- jQuery script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
   
  </head>

<body>
     
     <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="dashboard.php">Referral Tracker</a>
          <a class="navbar-brand brand-logo-mini" href="dashboard.php">
            <img src="" alt="logo" />
          </a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>

          <ul class="navbar-nav navbar-nav-right">
          
            <li class="nav-item d-none d-lg-block full-screen-link">
              <a class="nav-link">
                <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
              </a>
            </li>

          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <div class="nav-link">
                
                <div class="nav-profile-text d-flex flex-column">
                  
                </div>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="dashboard.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link"  href="profile.php" >
                <span class="menu-title">Account</span>
                <i class="mdi mdi-settings menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php">
                <span class="menu-title">Log Out</span>
                <i class="mdi mdi-logout  menu-icon"></i>
              </a>
            </li>


          </ul>
        </nav>
     
     <div class="main-panel">
          <div class="content-wrapper">
              <div class="row">
                   <div class="col-md-8  stretch-card grid-margin">
              <div class="page-header ">

<h1>Customer Details</h1>
              </div>
              </div>
              
                  <div class="col-md-4 col-md-offset-2 stretch-card grid-margin">
                <div class="card bg-gradient-info card-img-holder text-white">
                  <div class="card-body">
                    <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h4  class="font-weight-normal mb-3 text-center">Add Values </h4>
                    <button id="add-channel-btn">
                    <span class="iconify" data-icon="codicon:add" data-inline="false" style="width: 14rem; height: 1.8125rem;"></span>
                    </button>
                  </div>
                </div>
              </div> 
              </div>
              
<div class="stretch-card table-responsive" >
                <div class="card">
                  <div class="card-body ">
                  
                    <table  class="table table-hover table-bordered table-responsive">
                      <thead>
                         <tr class="bg-gradient-primary">
                       
                   <th>First Name</th>            
                <th>Phone Number</th>
                  <th>Referred By</th>
                  
                  <th>Transaction Amount</th>
                                           
  </tr>
                  </thead>
                      <tbody>
                          <?php

include "dbcon.php"; // Using database connection file here

$records = mysqli_query($con,"SELECT * FROM social_channel  "); // fetch data from database

while($data = mysqli_fetch_array($records))
{
?>
  <tr >

<td><?php echo $data['Client_Name']; ?></td>
 <td><?php echo $data['phone_no']; ?></td>
<td><?php echo $data['Ref_by']; ?></td>
<td><?php echo $data['Trans_amt']; ?></td>
 
  
  
    <td><a class="btn btn-gradient-success" href="edit.php?id=<?php echo $data['client_id']; ?>" role="button">Edit</a></td>
    <td>
        <a class="btn btn-gradient-danger" href="delete.php?id=<?php echo $data['client_id']; ?>" role="button">Delete</a></td>
  </tr>	
<?php
}
?>                     </tbody>
                    </table>
                  </div>
                </div>
              </div>
              </div>

 <div class="channelOption d-none" >
      <div class="channelOptionContent bg-gradient-primary" style="margin:-100px;">
             

    
    <div class="card-body " >
        
<form action="insert.php" method="POST" class="forms-sample ">
    <div class="form-group row">
    <label class="col-sm-4 col-form-label">First Name</label>
    <div class="col-sm-8">
      <input type="text"class="form-control" name="Client_Name"  placeholder=" First Name" Required>
    </div>
      </div>
   <div class="form-group row">
    <label  class="col-sm-4 col-form-label">Last Name</label>
    <div class="col-sm-8">
     <input type="text"class="form-control" name="client_lname"  placeholder="Last Name" Required>
    </div>
    </div>
     <div class="form-group row">
  <label  class="col-sm-4 col-form-label">Phone Number</label>
  <div class="col-sm-8">
    <input type="text" class="form-control" name="phone_no"  placeholder="Phone Number" Required>
  </div>
</div> 
   <div class="form-group row">
  <label  class="col-sm-4 col-form-label">Email</label>
  <div class="col-sm-8">
    <input type="text" class="form-control" name="email"  placeholder="Email" Required>
  </div>
</div> 

<div class="form-group row">
  <label  class="col-sm-4 col-form-label">Referred By</label>
  <div class="col-sm-8">
  <input type="text" class="form-control" name="referred_by"  placeholder="Referred By" Required> 
  </div>
</div>
    <div class="form-group row">
  <label  class="col-sm-4 col-form-label"> Ref By Email</label>
  <div class="col-sm-8">
    <input type="text" class="form-control" name="ref_mail"  placeholder="Ref Email" Required>
  </div>
</div> 
<div class="form-group row">
  <label  class="col-sm-4 col-form-label">Transaction Amount</label>
  <div class="col-sm-8">
   <input type="text" class="form-control" name="transaction_amount"  placeholder="Transaction Amount" Required>  
  </div>
</div>
 
 <input type="submit" class="btn btn-gradient-info" value="Submit">
  <div id="addChannelCancel" class="btn btn-light">Cancel</div>
</form>
            </div>
          </div>
      </div>
     
       
     </div>
     </div>
<footer class="footer">
            <div class="container-fluid clearfix" style="color: #444444;">
              <span class="d-block text-center text-left d-sm-inline-block">Copyright © <a style="text-decoration: none; color: #444444;" href="http://www.abcinfomedia.com">ABC Infomedia Pvt Ltd</a> • 2021</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">All Rights Reserved • <a style="color: #444444;" href="http://www.referraltracker.in" >ReferralTracker </a></span>
            </div>
          </footer>  
     </div>
 <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>
    <script src="dash_soumya.js" charset="utf-8"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
     
</body>
</html>