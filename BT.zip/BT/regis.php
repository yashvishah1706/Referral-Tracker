<?php

session_start();

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>SignUp | ReferralTracker</title>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
 <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli:400,600,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">

<style type="text/css">
	

.divider-text {
    position: relative;
    text-align: center;
    margin-top: 15px;
    margin-bottom: 15px;
}
.divider-text span {
    padding: 7px;
    font-size: 12px;
    position: relative;   
    z-index: 2;
}
.divider-text:after {
    content: "";
    position: absolute;
    width: 100%;
    border-bottom: 1px solid #ddd;
    top: 55%;
    left: 0;
    z-index: 1;
}

.btn-facebook {
    background-color: #405D9D;
    color: #fff;
}
.btn-twitter {
    background-color: #42AEEC;
    color: #fff;
}
</style>
</head>
<body id="home">
<?php 


include 'dbcon.php';

if (isset($_POST['submit'])){
	$username = mysqli_real_escape_string($con, $_POST['username']);        
	$email = mysqli_real_escape_string($con, $_POST['email']);
	
	$password = mysqli_real_escape_string($con, $_POST['password']);
	$cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);


    $pass = password_hash($password, PASSWORD_BCRYPT);
    $cpass = password_hash($cpassword, PASSWORD_BCRYPT);

    $emailquery = " select * from registration where email= '$email'";
    $query = mysqli_query($con, $emailquery);

    $emailcount = mysqli_num_rows($query);

    if ($emailcount>0) {
        ?>
<script>alert("  Email already exixts");</script>
<?php
    }else{
        if ($password === $cpassword) {
            $insertquery = "insert into registration(username,email,password,cpassword) values('$username','$email',    '$pass', '$cpass')";

            $iquery = mysqli_query($con, $insertquery);

if($iquery){
?>
<script>alert("inserted  successfull");</script>
<?php

}else {
    
    ?>
<script>alert("  no connection successfull");</script>
<?php
}


            
        }else{
            echo "password not matched";
        }
    }


}


 ?>
<section class=" w3l-header-4 header-sticky">
        <header class="absolute-top">
            <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <h1><a class="navbar-brand" href="index.php"><span class="fa fa-line-chart" aria-hidden="true"></span>
                   ReferralTracker
                </a></h1>
                <button class="navbar-toggler bg-gradient" type="button" data-toggle="collapse"
                    data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
          
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.html">About</a>
                        </li>
                       
               
                    </ul>
                    <ul class="navbar-nav search-righ">
                       <li class="nav-item" title="Login"><a href="login.php" class="btn search-search">Login</a></li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>
                    </ul>
                    <!-- search popup -->
                    <div id="search" class="pop-overlay">
                        <div class="popup">
                            <form action="#" method="GET" class="d-flex">
                                <input type="search" placeholder="Search.." name="search" required="required" autofocus>
                                <button type="submit">Search</button>
                                <a class="close" href="#">&times;</a>
                            </form>
                        </div>
                    </div>
                    <!-- /search popup -->
                </div>
           
  
            </nav>
        </div>
          </header>
    </section>



<div class="container">
<br>  
<br>





<div class="card bg-light">
<article class="card-body mx-auto" style="max-width: 400px;"><i class="fa fa-google"></i>
	<h4 class="card-title mt-3 text-center" style="font-size: 30px;">Create Account</h4>
	<p class="text-center">Get started with your free account</p>
	<br>  
<br>
	
	<form action="<?php echo htmlentities( $_SERVER['PHP_SELF']); ?>" method="POST">


	<div class="form-group input-group">
		<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-user"></i> </span>
		 </div>
        <input name="username" class="form-control" placeholder="Username" type="text" required="">
    </div> 


    <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
		 </div>
        <input name="email" class="form-control" placeholder="Email address" type="email" required="">
    </div> 


   




    <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
		</div>
        <input class="form-control" placeholder="Create password" type="password" name="password">
    </div> 




    <!-- form-group// -->
    <div class="form-group input-group">
    	<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
		</div>
        <input class="form-control" placeholder="Repeat password" type="password" name="cpassword">
    </div>



     <!-- form-group// -->                                      
    <div class="form-group">
        <button type="submit" name="submit" class="btn btn-primary btn-block"> Create Account  </button>
    </div> <!-- form-group// -->      
    <p class="text-center">Have an account? <a href="login.php">Log In</a> </p>                                                                 
</form>
</article>
</div> <!-- card.// -->

</div> 
<!--container end.//-->

<br><br>









   




    
<br><br>
<section style="margin-top: 70px"class="w3l-footers-20">
	<div class="footers20">
		<div class="container">
			<h2><a class="footer-logo" href="index.html">
				<span class="fa fa-line-chart mr-2"aria-hidden="true"></span>ReferralTrackers</a></h2>
			<div class=" row">
				<div class="grid-col col-lg-7 col-md-7">
					<h3>Get latest updates and offers.</h3>
					<div class="footer-subscribe mt-4">
						<form action="#" method="post" class="input-button">
							<input type="email" name="Your Email" class="form-control" placeholder="Your Email"
								required="">
							<button class="btn footer-button btn-secondary action-button">
								Subscribe
							</button>
						</form>
					</div>
				</div>
				<div class="col-lg-5 col-md-5 footer-bottom-two">
					<ul>
						<li> <a href="contact.php" class="btn action-sub-button">Contact</a></li>
					</ul>
				</div>

			</div>
			<div class="border-line-bottom"></div>
			<div class=" row">
				<div class="grids-content col-lg-2 col-md-2 col-sm-6">
					<h4>Company</h4>
					<div class="footer-nav">
						<a href="index.html" class="contact-para3">Home</a>
						<a href="about.html" class="contact-para3">About</a>
						<a href="contact.php" class="contact-para3">Contact</a>
					</div>

				</div>
				<div class="grids-content col-lg-3 col-md-3 col-sm-6">
				<h4>Contact Information</h4>
					<a href="mailto:support@abcinfomedia.in">
						<p class="contact-text-sub contact-para3">support@abcinfomedia.in</p>
					</a>
					<a href="tel:+91-97900 30919">
						<p class="contact-text-sub contact-para3">+91-97900 30919</p>
					</a>
					<a href="tel:+91-76039-11111">
						<p class="contact-text-sub contact-para3">+91-76039-11111</p>
					</a>
					<p class="contact-text-sub contact-para3">No.32, Vinayagar Kovil Street, Karungalpalayam, Erode - 638003 </p> 
					<p class="contact-text-sub contact-para3">Tamil Nadu, India</p>
					<div class="buttons-teams">
						<a href="https://www.facebook.com/abcinfomediapvtltd/"> <span class="fa fa-facebook" aria-hidden="true"> </span> </a>
						<a href="https://twitter.com/abc_infomedia"><span class="fa fa-twitter" aria-hidden="true"></span></a>
						<a href="https://www.linkedin.com/in/abcinfomedia/"><span class="fa fa-linkedin" aria-hidden="true"></span></a>
					</div>
				</div>
				<div class="col-lg-7 col-md-7 col-12 copyright-grid ">
					<p class="copy-footer-29">© 2021, All rights reserved
					</p>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
</section>
<?php

header('location:dasboard.php');

?>
</body>
</html>