<!--
   Author: W3layouts
   Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>ReferralTracker | Contact Us</title>

    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli:400,600,700&display=swap" rel="stylesheet">
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        .status{
                color: green;
                font-weight: bolder;
                font-size: 1.2rem;
                margin-top: 20px;
                /* text-align: center; */
               }
    </style>
  </head>
  <body id="home">
<section class=" w3l-header-4 header-sticky">
        <header class="absolute-top">
            <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <h1><a class="navbar-brand" href="index.php"><span class="fa fa-line-chart" aria-hidden="true"></span>
                   ReferralTracker
                </a></h1>
                <button class="navbar-toggler bg-gradient" type="button" data-toggle="collapse"
                    data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
          
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.html">About</a>
                        </li>
                     
                    </ul>
                    <ul class="navbar-nav search-righ">
                      <li class="nav-item" title="Login"><a href="login.php" class="btn search-search">Login</a></li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                    <!-- search popup -->
                    <!-- <div id="search" class="pop-overlay">
                        <div class="popup">
                            <form action="#" method="GET" class="d-flex">
                                <input type="search" placeholder="Search.." name="search" required="required" autofocus>
                                <button type="submit">Search</button>
                                <a class="close" href="#">&times;</a>
                            </form>
                        </div>
                    </div> -->
                    <!-- /search popup -->
                </div>
            </div>
  
            </nav>
        </div>
          </header>
    </section>

    <script src="assets/js/jquery-3.3.1.min.js"></script> <!-- Common jquery plugin -->
    <!--bootstrap working-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- //bootstrap working-->
<!-- disable body scroll which navbar is in active -->
<script>
    $(function () {
      $('.navbar-toggler').click(function () {
        $('body').toggleClass('noscroll');
      })
    });
  </script>
  <!-- disable body scroll which navbar is in active -->


<!-- breadcrumbs -->
    <section class="w3l-inner-banner-main">
        <div class="about-inner inner2">
            <div class="container seen-w3">
                <ul class="breadcrumbs-custom-path">
                    <li><a href="index.html">Home <span class="fa fa-angle-right" aria-hidden="true"></span></a></li>
                    <li class="active">Contact</li>
                </ul>
            </div>
        </div>
    </section>
<!-- breadcrumbs //-->
<section class="w3l-contact-info-main">
    <div class="contact-sec">
        <div class="container">
            <div class="main-titles-head text-center">
                <h3 class="header-name">
                    Drop us Message for any Query
                </h3> 

            </div>
            <div class="contact row">
                <!-- email -->
                <div class="col-lg-3 col-md-6 col-sm-6 contact-grids" style="margin-left:150px;">
                    <div class="contact-gtids ">
                        <span class="fa fa-envelope" aria-hidden="true"></span>
                    <h4>Email Address</h4>
                <a href="mailto:support@abcinfomedia.in">
                    <p class="contact-text-sub">support@abcinfomedia.in <br> <br></p>
                </a>
            </div>
            </div>
            <!-- phone -->
            <div class=" col-lg-3 col-md-6 col-sm-6 contact-grids">
                <div class="contact-gtids ">
                    <span class="fa fa-phone" aria-hidden="true"></span>
                <h4>Phone Number</h4>
                <a href="tel:+91-97900 30919">
                    <p class="contact-text-sub">+91-97900 30919</p>
                </a>
                <a href="tel:+91-76039-11111">
                    <p class="contact-text-sub">+91-76039-11111</p>
                </a>
            </div>
            </div>
                <!-- address -
                <div class="col-lg-3 col-md-6 col-sm-6 contact-grids">
                    <div class="contact-gtids ">
                        <span class="fa fa-building" aria-hidden="true"></span>
                    <h4>Address Line</h4>
                <p class="contact-text-sub" style="font-size:10px;">No.32, Vinayagar Kovil Street - 638003, Tamil Nadu, India</p>
    
            </div>
        </div>
 24 customer service -->
                <div class="col-lg-3 col-md-6 col-sm-6 contact-grids">
                    <div class="contact-gtids ">
                        <span class="fa fa-headphones" aria-hidden="true"></span>
                    <h4>Support</h4>
                    <p class="contact-text-sub">24/7 Ready - Our Support Team For You.</p>

                </div>
            </div>
            </div>
			
             <form action=" " method="post" enctype="multipart/form-data" class="w3layouts-contact-fm" id="my_captcha_form">
			 
                <div class="row main-cont-sec">
				
                    <div class="col-lg-6 left-cont-contact">
					
                        <div class="form-group input-gap">
                            <input class="form-control" type="text" name="fname" id="w3lName" placeholder="First Name"
                                required="">
                        </div>
                        <div class="form-group input-gap">
                            <input class="form-control" type="text" name="lname" id="w3lName" placeholder="Last Name"
                                required="">
                        </div>
                        <div class="form-group input-gap">
                            <input class="form-control" type="email" name="email" id="w3lSender" placeholder="Email"
                                required="">
                        </div>
                    </div>
                    <div class="col-lg-6 right-cont-contact">
                        <div class="form-group">
                            <textarea class="form-control" name="msg" id="w3lMessage" placeholder="Write Message"
                                required=""></textarea>
                        </div>
                    </div>
                </div>
				<div class="form_container" >
 
                    <div class="g-recaptcha" data-sitekey="6Lf1cdcbAAAAAFqWMHhd-_-XuLHxs1bffAPPyadq"></div>
 
                </div>
 
                <div class="form-group-2"  >
                    <button  type="submit" class="btn action-button mt-3" name="submit" value="Send">Send Now</button>
                </div>
				<div class="status">
				 <?php

                   // $errors = "";

                   if(isset($_POST["submit"])) {

                     //captcha code
                     $secretKey = "6Lf1cdcbAAAAALTzRXZcAz9BeV-HwDxPlilsfYS3";
                     //6Lc4hRMbAAAAAIlsArPhq0SQtpdsOSrheZa4-d1G
                     $responseKey = $_POST["g-recaptcha-response"];
                     $user_ip = $_SERVER['REMOTE_ADDR'];
                     $url = "https://www.google.com/recaptcha/api/siteverify?secret=". $secretKey. "&response=" . $responseKey . "&remoteip=" . $user_ip;

                     function curl_get_file_contents($URL)
                                  {
                                      $c = curl_init();
                                      curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
                                      curl_setopt($c, CURLOPT_URL, $URL);
                                      $contents = curl_exec($c);
                                      curl_close($c);

                                      if ($contents) return $contents;
                                      else return FALSE;
                                  }
                     $response = curl_get_file_contents($url);
                     $response = json_decode($response);

                     if ($response-> success)
                     {
                       // code...

                       $myMail = "referraltracker3@gmail.com"; //host email


                       $fname = $_POST['fname'];
                       $lname = $_POST['lname'];
                       $email = $_POST['email']; //email written by visitor
                       $message = $_POST['msg'];
                      



                       //setting email for Acknowledgment
                       $from = $myMail;
                       $to_email = $email;
                       $subject = "Acknowledgment Email from Referral Trackers";
                       $body = "\nHi,"
                               . "\n\nWe have recieved your enquiry. Our Team will reach you soon."
                               . "\n\nResponse submitted by you:\n\n"
                               . "Name: " .$fname . " " .$lname."\n\nMessage: ".$message
                               ."\n\nEmail: ". $email;
                       $headers = "From: ". $myMail ;
                       if(mail($to_email, $subject, $body, $headers) ){
                         echo "Thank You! We recieved your enquiry.";
                       } else {
                         echo "Email failed.";
                       }
                       //Acknowledgment mail end


                       //mail new response recieved from contact-us
                       $from = $myMail;
                       $office_mail = "referraltracker3@gmail.com";
                       $to_email = "ayesha19ab@gmail.com";
                       $officeSubject = "New Contact Form Submission";
                       $officeBody = "\nHere are the details:\n\n"
                               ."Name: ".$fname." ".$lname
                               ."\n\nEmail: ". $email
                               
                               ."\n\nMessage: ". $message;
                       $headers = "From:". $from ;
                          if(mail($to_email, $officeSubject, $officeBody, $headers)){
                            echo " We'll reach you soon.\n";
                          }
                          else{
                            echo "Something Went wrong! Please try again.";
                          }

                       // end

                     } else {
                       echo "<span  style=\" color: red; font-weight: bolder;
                       font-size: 1.2rem;
                       text-align: center;\" >";
                       echo "Please enter captcha!";
                       echo "</span>";
                     }

                       // header('Location:/signup/contact.php');

                    }
                   ?>
				</div>
            </form>
            
        </div>
    </div>
    </div>
</section>
<section class="w3l-footers-20">
	<div class="footers20">
		<div class="container">
			<h2><a class="footer-logo" href="index.html">
				<span class="fa fa-line-chart mr-2"aria-hidden="true"></span>ReferralTracker</a></h2>
			<div class=" row">
				<div class="grid-col col-lg-7 col-md-7">
					<h3>Get latest updates and offers.</h3>
					<div class="footer-subscribe mt-4">
						<form action="#" method="post" class="input-button">
							<input type="email" name="Your Email" class="form-control" placeholder="Your Email"
								required="">
							<button class="btn footer-button btn-secondary action-button">
								Subscribe
							</button>
						</form>
					</div>
				</div>
				<div class="col-lg-5 col-md-5 footer-bottom-two">
					<ul>
						<li> <a href="contact.html" class="btn action-sub-button">Contact</a></li>
					</ul>
				</div>

			</div>
			<div class="border-line-bottom"></div>
			<div class=" row">
				<div class="grids-content col-lg-2 col-md-2 col-sm-6">
					<h4>Company</h4>
					<div class="footer-nav">
						<a href="index.html" class="contact-para3">Home</a>
						<a href="about.html" class="contact-para3">About</a>
						<a href="contact.html" class="contact-para3">Contact</a>
					</div>

				</div>
				<div class="grids-content col-lg-3 col-md-3 col-sm-6">
				<h4>Contact Information</h4>
					<a href="mailto:support@abcinfomedia.in">
						<p class="contact-text-sub contact-para3">support@abcinfomedia.in</p>
					</a>
					<a href="tel:+91-97900 30919">
						<p class="contact-text-sub contact-para3">+91-97900 30919</p>
					</a>
					<a href="tel:+91-76039-11111">
						<p class="contact-text-sub contact-para3">+91-76039-11111</p>
					</a>
					<p class="contact-text-sub contact-para3">No.32, Vinayagar Kovil Street, Karungalpalayam, Erode - 638003 </p> 
					<p class="contact-text-sub contact-para3">Tamil Nadu, India</p>
					<div class="buttons-teams">
						<a href="https://www.facebook.com/abcinfomediapvtltd/"> <span class="fa fa-facebook" aria-hidden="true"> </span> </a>
						<a href="https://twitter.com/abc_infomedia"><span class="fa fa-twitter" aria-hidden="true"></span></a>
						<a href="https://www.linkedin.com/in/abcinfomedia/"><span class="fa fa-linkedin" aria-hidden="true"></span></a>
					</div>
				</div>
				<div class="col-lg-7 col-md-7 col-12 copyright-grid ">
					<p class="copy-footer-29">© 2021, All rights reserved
					</p>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
</section>

<!-- move top -->
<button onclick="topFunction()" id="movetop" title="Go to top">
	<span class="fa fa-angle-up"></span>
</button>
<script>
	// When the user scrolls down 20px from the top of the document, show the button
	window.onscroll = function () {
		scrollFunction()
	};

	function scrollFunction() {
		if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
			document.getElementById("movetop").style.display = "block";
		} else {
			document.getElementById("movetop").style.display = "none";
		}
	}

	// When the user clicks on the button, scroll to the top of the document
	function topFunction() {
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
	}
</script>
<!-- /move top -->


<script type="text/javascript">
  document.getElementById("my_captcha_form").addEventListener("submit",function(evt)
  {
  
  var response = grecaptcha.getResponse();
  if(response.length == 0) 
  { 
    //reCaptcha not verified
    alert("please verify you are humann!"); 
    evt.preventDefault();
    return false;
  }
  
});
function button(){
alert ("form submitted successfully");
}
</script>

</body>

</html>