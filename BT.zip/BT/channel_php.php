<?php
session_start();
/*
*
* sql connection
*/
  $server = "localhost";
$user = "referraltracker_db";
$password = "RefeRRal121@Track";
$db = "referraltracker_db";
    // Create connection
    $conn = new mysqli($server,$user,$password,$db);

    /* Check connection */
    if($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    /*
    *
    * sql connection
    */
     $current_user = $_SESSION['username'];
    $data_query = $conn->query("SELECT * FROM registration WHERE username = '{$current_user}'");
    while($data = $data_query->fetch_assoc()){
      $profile_no = $data['Profile_No'];
      $user = $data['username'];
      $company = $data['company_name'];
    }
     $_SESSION['profile_no'] = $profile_no ;

    $channel_name = $conn->real_escape_string($_POST['channel_name']);
    

    $query = "INSERT INTO dashboard ( Profile_No, Channel_Name)
                VALUES ('{$profile_no}', '{$channel_name}')";

    $conn->query($query);

    header("Location:addChannel.php");
    $conn->close();
?>
