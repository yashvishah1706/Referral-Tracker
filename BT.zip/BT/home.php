<?php 	
session_start()	;

if (	!isset(	$_SESSION['username'])) {
	echo "	you are logged out";
		header	('location:login.php');
}
 ?>


<!DOCTYPE html>
<html>
<head>
	<title>	home</title>
</head>
<body>
<h1>welcome  <?php 	echo $_SESSION['username']; ?></h1>


<div>	
<a href="logout.php" style="width: 300px; height: 200px; background-color: yellow; padding:20px;">Logout</a>
</div>
</body>
</html>